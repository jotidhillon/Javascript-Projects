function finalcost(){
    let meal = +document.getElementById("box1").value;
    let tip = +document.getElementById("box2").value;
    let tipamount = (tip/100) * meal;
    let cost = meal + tipamount;
    document.getElementById("output").innerHTML = "Your meal costs " + "$" + cost + " and the tip was " + "$"+ tipamount;
}