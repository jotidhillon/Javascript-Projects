function add() {
    let val1 = +document.getElementById("box1").value;
    let val2 = +document.getElementById("box2").value;
    let addition = val1 + val2;
    document.getElementById("box3").value = addition;
}
function subtract() {
    let val1 = +document.getElementById("box1").value;
    let val2 = +document.getElementById("box2").value;
    let subtraction = val1 - val2;
    document.getElementById("box3").value = subtraction;
}
function multiply() {
    let val1 = +document.getElementById("box1").value;
    let val2 = +document.getElementById("box2").value;
    let multiplication = val1 * val2;
    document.getElementById("box3").value = multiplication;
}
function divide() {
    let val1 = +document.getElementById("box1").value;
    let val2 = +document.getElementById("box2").value;
    let division = val1 / val2;
    document.getElementById("box3").value = division;
}
function resetAll() {
    document.getElementById("box1").value = "";
    document.getElementById("box2").value = "";
    document.getElementById("box3").value = "";
}