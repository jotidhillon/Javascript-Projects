let time
let timer

function counting() {
    time = +document.getElementById("box1").value;
    timer = setInterval(realCounter, 1000);
    document.getElementById("output1").innerHTML = time;
}

function realCounter() {
    if (time > 0 && time <= 100) {
        time = (time - 1);
        let timeDisplay = +document.getElementById("output1").value;
        timeDisplay.innerHTML = time;
        document.getElementById("output1").innerHTML = time;
    }
    else if (time === 0) {
        clearInterval(timer);
    }
    else {
        alert("Number is Invalid");
        clearInterval(timer);
        document.getElementById("output1").innerHTML = "0";
    }
}

function reset() {
    clearInterval(timer);
    document.getElementById("output1").innerHTML = "0";
}